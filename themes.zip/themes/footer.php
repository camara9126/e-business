<?php if (!($_SESSION["user"])): ?>

</div>
</div>
<!-- content-wrapper ends -->
<!-- partial:partials/_footer.html -->
<footer class="footer">
    <div class="footer-inner-wraper">
        <div class="d-sm-flex justify-content-center justify-content-sm-between">
            <span class="text-muted d-block text-center text-sm-left d-sm-inline-block">Copyright ©
                uasbc.net 2024</span>
        </div>
    </div>
</footer>
<!-- partial -->
</div>
<!-- main-panel ends -->
</div>
<!-- page-body-wrapper ends -->
</div>
<!-- container-scroller -->
<?php endif; ?>

<!-- plugins:js -->
<script src="themes/vendors/js/vendor.bundle.base.js"></script>
<!-- endinject -->
<!-- Plugin js for this page -->
<script src="themes/vendors/chart.js/Chart.min.js"></script>
<script src="themes/vendors/jquery-circle-progress/js/circle-progress.min.js"></script>
<!-- End plugin js for this page -->
<!-- inject:js -->
<script src="themes/js/off-canvas.js"></script>
<script src="themes/js/hoverable-collapse.js"></script>
<script src="themes/js/misc.js"></script>
<!-- endinject -->
<!-- Custom js for this page -->
<script src="themes/js/dashboard.js"></script>
<!-- End custom js for this page -->
</body>

</html>